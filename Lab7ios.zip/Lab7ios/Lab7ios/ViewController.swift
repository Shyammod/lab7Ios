//
//  ViewController.swift
//  Lab7ios
//
//  Created by user228349 on 7/14/24.
//


import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    
    
    
    @IBOutlet weak var startTripButton: UIButton!
    @IBOutlet weak var stopTripButton: UIButton!
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var maxSpeedLabel: UILabel!
    @IBOutlet weak var averageSpeedLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var maxAccelerationLabel: UILabel!
    @IBOutlet weak var topBar: UIView!
    @IBOutlet weak var bottomBar: UIView!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var current: UILabel!
    
    @IBOutlet weak var Max: UILabel!
    
    @IBOutlet weak var Average: UILabel!
    
    @IBOutlet weak var Distance: UILabel!
    
    @IBOutlet weak var MaxAcc: UILabel!
    
    
    
        var locationManager: CLLocationManager!
        var tripStarted = false
        var maxSpeed: CLLocationSpeed = 0
        var totalSpeed: CLLocationSpeed = 0
        var speedCount: Int = 0
        var distanceTraveled: CLLocationDistance = 0
        var lastLocation: CLLocation?
        var maxAcceleration: CLLocationSpeed = 0
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.requestWhenInUseAuthorization()
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
        }
        
        @IBAction func startTrip(_ sender: UIButton) {
            tripStarted = true
//            maxSpeed = 0
//            totalSpeed = 0
//            speedCount = 0
//            distanceTraveled = 0
//            lastLocation = nil
//            maxAcceleration = 0
//
            topBar.backgroundColor = .clear
            bottomBar.backgroundColor = .green
            
            locationManager.startUpdatingLocation()
            locationManager.startUpdatingLocation()
                       mapView.showsUserLocation = true
        }
        
        @IBAction func stopTrip(_ sender: UIButton) {
            tripStarted = false
            locationManager.stopUpdatingLocation()
            
            topBar.backgroundColor = .clear
            bottomBar.backgroundColor = .red
        }
        
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            guard let location = locations.last else { return }
            
            let speed = location.speed
            speedLabel.text = String(format: "%.2f km/h", speed * 3.6)
            
            if speed > maxSpeed {
                maxSpeed = speed
                maxSpeedLabel.text = String(format: "%.2f km/h", maxSpeed * 3.6)
            }
            
            totalSpeed += speed
            speedCount += 1
            let averageSpeed = totalSpeed / Double(speedCount)
            averageSpeedLabel.text = String(format: "%.2f km/h", averageSpeed * 3.6)
            
            if let lastLocation = lastLocation {
                let distance = location.distance(from: lastLocation)
                distanceTraveled += distance
                distanceLabel.text = String(format: "%.2f km", distanceTraveled / 1000)
                
                let acceleration = abs(speed - lastLocation.speed)
                if acceleration > maxAcceleration {
                    maxAcceleration = acceleration
                    maxAccelerationLabel.text = String(format: "%.2f m/s²", maxAcceleration)
                }
            }
            
            lastLocation = location
            
            if speed > 31.94 { // 115 km/h in m/s
                topBar.backgroundColor = .green
            } else {
                topBar.backgroundColor = .green
            }
            
        
            let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
            mapView.setRegion(region, animated: true)
            
            
            if averageSpeed > 0 {
                let distanceBeforeLimit = (115 / 3.6 - averageSpeed) * (distanceTraveled / averageSpeed)
                distanceLabel.text = String(format: "%.2f km", distanceBeforeLimit / 1000)
            } else {
                distanceLabel.text = "N/A"
            }
            
            mapView.showsUserLocation = true
        }
    }

